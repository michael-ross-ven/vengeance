
""" https://github.com/michael-ross-ven/vengeance/blob/master/releases.log """
__version__ = '1.1.1'
__release__ = '$release 39'

__all__ = ['__version__',
           '__release__']
