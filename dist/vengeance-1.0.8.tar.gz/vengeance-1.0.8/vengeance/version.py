
# generated from setup.py
__version__ = '1.0.8'
__release__ = '$release 2'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
