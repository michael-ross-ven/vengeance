
# generated from setup.py
__version__ = '1.0.41'
__release__ = '$release 34'


