
""" https://github.com/michael-ross-ven/vengeance/blob/master/releases.log """
__version__ = '1.1.2'
__release__ = '$release 40'

__all__ = ['__version__',
           '__release__']
