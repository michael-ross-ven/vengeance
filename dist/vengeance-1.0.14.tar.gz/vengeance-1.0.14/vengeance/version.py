
# generated from setup.py
__version__ = '1.0.14'
__release__ = '$release 6'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
