
__version__ = '1.1.0'
__release__ = '$release 38'

__all__ = ['__version__',
           '__release__']
