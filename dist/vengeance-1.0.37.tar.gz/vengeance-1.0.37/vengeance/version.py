
# generated from setup.py
__version__ = '1.0.37'
__release__ = '$release 30'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil')
