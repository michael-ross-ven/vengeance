
# generated from setup.py
__version__ = '1.0.12'
__release__ = '$release 5'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
