
# generated from setup.py
__version__ = '1.0.6'
__release__ = '$release 2'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
