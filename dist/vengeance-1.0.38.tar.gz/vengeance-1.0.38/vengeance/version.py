
# generated from setup.py
__version__ = '1.0.38'
__release__ = '$release 31'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil')
