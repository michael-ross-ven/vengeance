
# generated from setup.py
__version__ = '1.0.22'
__release__ = '$release 13'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
