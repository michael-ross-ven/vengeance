
# generated from setup.py
__version__ = '1.0.36'
__release__ = '$release 29'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil')
