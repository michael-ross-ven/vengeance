
# generated from setup.py
__version__ = '1.0.31'
__release__ = '$release 24'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
