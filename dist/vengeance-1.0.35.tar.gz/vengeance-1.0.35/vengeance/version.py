
# generated from setup.py
__version__ = '1.0.35'
__release__ = '$release 28'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil')
