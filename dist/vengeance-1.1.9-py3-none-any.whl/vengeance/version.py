
""" https://github.com/michael-ross-ven/vengeance/blob/master/releases.log """
__version__ = '1.1.9'
__release__ = '$release 47'

__all__ = ['__version__',
           '__release__']
