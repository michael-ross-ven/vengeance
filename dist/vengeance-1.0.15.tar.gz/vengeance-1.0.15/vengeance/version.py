
# generated from setup.py
__version__ = '1.0.15'
__release__ = '$release 7'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
