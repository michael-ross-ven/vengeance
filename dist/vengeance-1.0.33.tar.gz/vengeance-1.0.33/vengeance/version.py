
# generated from setup.py
__version__ = '1.0.33'
__release__ = '$release 26'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
