
# generated from setup.py
__version__ = '1.0.26'
__release__ = '$release 19'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
