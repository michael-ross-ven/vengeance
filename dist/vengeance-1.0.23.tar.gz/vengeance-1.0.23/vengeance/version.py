
# generated from setup.py
__version__ = '1.0.23'
__release__ = '$release 16'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
