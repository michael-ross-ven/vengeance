
# generated from setup.py
__version__ = '1.0.20'
__release__ = '$release 11'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
