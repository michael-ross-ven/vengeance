
""" https://github.com/michael-ross-ven/vengeance/blob/master/releases.log """
__version__ = '1.1.4'
__release__ = '$release 42'

__all__ = ['__version__',
           '__release__']
