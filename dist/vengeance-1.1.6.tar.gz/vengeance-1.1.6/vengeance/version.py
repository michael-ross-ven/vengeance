
""" https://github.com/michael-ross-ven/vengeance/blob/master/releases.log """
__version__ = '1.1.6'
__release__ = '$release 44'

__all__ = ['__version__',
           '__release__']
