
# generated from setup.py
__version__ = '1.0.24'
__release__ = '$release 17'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
