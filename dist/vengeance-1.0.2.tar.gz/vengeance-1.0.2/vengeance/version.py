
# generated from setup.py
__version__  = '1.0.2'
dependencies = ('comtypes', 'pypiwin32', 'line_profiler', 'pandas', 'pyodbc')
