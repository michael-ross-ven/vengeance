
# generated from setup.py
__version__ = '1.0.27'
__release__ = '$release 20'

dependencies = ('comtypes', 'pypiwin32', 'python-dateutil', 'pyodbc')
