
""" https://github.com/michael-ross-ven/vengeance/blob/master/releases.log """
__version__ = '1.1.8'
__release__ = '$release 46'

__all__ = ['__version__',
           '__release__']
